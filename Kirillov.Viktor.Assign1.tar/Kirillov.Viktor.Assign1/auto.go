package auto

import (
	"ethos/primitiveEncode"
	"bytes"
	"fmt"
	"io"
	"os"
)

// Struct ...
type Struct interface {
	Encode() []byte
	Decode(b []byte)
	TypeId() uint32
}

// Mapping of a TypeId to the function that creates
//	an associated Struct object
var typeToFunc map[uint32]func() Struct

func init() {
	typeToFunc = make(map[uint32]func() Struct)
}

// SetType maps the given TypeId with the function
// 	that creates a struct associated with that TypeId
func SetType(TypeId uint32, fn func() Struct) {
	typeToFunc[TypeId] = fn
}

// Factory returns the pointer to the newly created struct
// 	that is associated with the given TypeId
func Factory(TypeId uint32) *Struct {
	a := typeToFunc[TypeId]()
	return &a
}

// Read reads an encoded byte slice from a file at the given system path,
// 	decodes the TypeId of the encoded struct, and if TypeId is valid,
// 	returns a decoded struct
func Read(path string) (Struct, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	buf := bytes.NewBuffer(nil)
	_, err = io.Copy(buf, f)
	if err != nil {
		return nil, err
	}

	bytes := buf.Bytes()

	// Safely translate encoded TypeId as int32 value back to uint32
	decodedTypeID := primitiveEncode.DecodeInt32(bytes[:4])
	var actualTypeID uint32 = uint32(2147483647) - uint32(decodedTypeID)

	if _, ok := typeToFunc[actualTypeID]; !ok {
		return nil, fmt.Errorf("Unable to find creation function for TypeId %d", actualTypeID)
	}

	createdStruct := *(Factory(actualTypeID))
	createdStruct.Decode(bytes[4:])

	return createdStruct, nil
}

// Write writes a given struct to a file at a given system path
//	in the format []byte{encodedInt32(t.TypeId()) + t.Encode()}
func Write(path string, t Struct) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()

	// Safely translate uint32 TypeId to the int32 value
	var typeID int32 = int32(uint32(2147483647) - t.TypeId())
	encodedTypeID := primitiveEncode.EncodeInt32(typeID)
	encodedStruct := t.Encode()

	_, err = f.Write(append(encodedTypeID, encodedStruct...))
	if err != nil {
		return err
	}

	return nil
}
