package primitiveEncode

import (
	"encoding/binary"
)

// EncodeInt32 ...
func EncodeInt32(x int32) []byte {
	b := make([]byte, 4)
	binary.LittleEndian.PutUint32(b, uint32(x))
	return b
}

// DecodeInt32 ...
func DecodeInt32(b []byte) int32 {
	return int32(binary.LittleEndian.Uint32(b))
}

// EncodeUint64 ...
func EncodeUint64(x uint64) []byte {
	b := make([]byte, 8)
	binary.LittleEndian.PutUint64(b, x)
	return b
}

// DecodeUint64 ...
func DecodeUint64(b []byte) uint64 {
	return binary.LittleEndian.Uint64(b)
}

// EncodeString ...
func EncodeString(x string) []byte {
	encoded := []byte(x)
	return append(EncodeInt32(int32(len(encoded))), encoded...)
}

// DecodeString ...
func DecodeString(b []byte) string {
	return string(b[4:])
}

// EncodeInt32Slice ...
func EncodeInt32Slice(x []int32) []byte {
	inputLength := len(x)
	encoded := make([]byte, 0, 4+4*inputLength)                   // allocate enough space
	encoded = append(encoded, EncodeInt32(int32(inputLength))...) // encode prefix
	for _, v := range x {                                         // encode each element in a slice
		encoded = append(encoded, EncodeInt32(v)...)
	}
	return encoded
}

// DecodeInt32Slice ...
func DecodeInt32Slice(b []byte) []int32 {
	inputLength := len(b)
	decoded := make([]int32, 0, inputLength/4-1) // allocate enough space
	for i := 4; i < inputLength; i += 4 {        // decode each element in a given slice EXCEPT the first 4 bytes (size)
		decoded = append(decoded, DecodeInt32(b[i:i+4]))
	}
	return decoded
}

// EncodeUint64Slice ...
func EncodeUint64Slice(x []uint64) []byte {
	inputLength := len(x)
	encoded := make([]byte, 0, 4+8*inputLength)                   // allocate enough space
	encoded = append(encoded, EncodeInt32(int32(inputLength))...) // encode prefix
	for _, v := range x {                                         // encode each element in a slice
		encoded = append(encoded, EncodeUint64(v)...)
	}
	return encoded
}

// DecodeUint64Slice ...
func DecodeUint64Slice(b []byte) []uint64 {
	inputLength := len(b)
	decoded := make([]uint64, 0, inputLength/8-1) // allocate enough space
	for i := 4; i < inputLength; i += 8 {         // decode each element in a given slice EXCEPT the first 4 bytes (size)
		decoded = append(decoded, DecodeUint64(b[i:i+8]))
	}
	return decoded
}
