package primitiveEncode

import (
	"bytes"
	"encoding/binary"
)

func encodePrimitive(x interface{}) []byte {
	buf := new(bytes.Buffer)
	binary.Write(buf, binary.LittleEndian, x)
	return buf.Bytes()
}

func decodePrimitive(b []byte, x interface{}) interface{} {
	binary.Read(bytes.NewReader(b), binary.LittleEndian, x)
	return x
}

// EncodeInt32 ...
func EncodeInt32(x int32) []byte {
	return encodePrimitive(x)
}

// DecodeInt32 ...
func DecodeInt32(b []byte) int32 {
	var x int32
	return *decodePrimitive(b, &x).(*int32)
}

// EncodeUint64 ...
func EncodeUint64(x uint64) []byte {
	return encodePrimitive(x)
}

// DecodeUint64 ...
func DecodeUint64(b []byte) uint64 {
	var x uint64
	return *decodePrimitive(b, &x).(*uint64)
}

// EncodeString ...
func EncodeString(x string) []byte {
	encoded := []byte(x)
	return append(EncodeInt32(int32(len(encoded))), encoded...)
}

// DecodeString ...
func DecodeString(b []byte) string {
	return string(b[4:])
}

// EncodeInt32Slice ...
func EncodeInt32Slice(x []int32) []byte {
	inputLength := len(x)
	encoded := make([]byte, 0, 4+4*inputLength)                   // allocate enough space
	encoded = append(encoded, EncodeInt32(int32(inputLength))...) // encode prefix
	for _, v := range x {                                         // encode each element in a slice
		encoded = append(encoded, EncodeInt32(v)...)
	}
	return encoded
}

// DecodeInt32Slice ...
func DecodeInt32Slice(b []byte) []int32 {
	inputLength := len(b)
	decoded := make([]int32, 0, inputLength/4-1) // allocate enough space
	for i := 4; i < inputLength; i += 4 {        // decode each element in a given slice EXCEPT the first 4 bytes (size)
		decoded = append(decoded, DecodeInt32(b[i:i+4]))
	}
	return decoded
}

// EncodeUint64Slice ...
func EncodeUint64Slice(x []uint64) []byte {
	inputLength := len(x)
	encoded := make([]byte, 0, 4+8*inputLength)                   // allocate enough space
	encoded = append(encoded, EncodeInt32(int32(inputLength))...) // encode prefix
	for _, v := range x {                                         // encode each element in a slice
		encoded = append(encoded, EncodeUint64(v)...)
	}
	return encoded
}

// DecodeUint64Slice ...
func DecodeUint64Slice(b []byte) []uint64 {
	inputLength := len(b)
	decoded := make([]uint64, 0, inputLength/8-1) // allocate enough space
	for i := 4; i < inputLength; i += 8 {         // decode each element in a given slice EXCEPT the first 4 bytes (size)
		decoded = append(decoded, DecodeUint64(b[i:i+8]))
	}
	return decoded
}
