package main

import (
	"ethos/auto"
	"ethos/primitiveEncode"
	"fmt"
)

// Single value example
type struct1 struct {
	value []int32
}

func (s *struct1) Encode() []byte {
	return primitiveEncode.EncodeInt32Slice(s.value)
}
func (s *struct1) Decode(b []byte) {
	s.value = primitiveEncode.DecodeInt32Slice(b)
}
func (s *struct1) TypeId() uint32 {
	return 1
}

// Compound value example
type struct2 struct {
	value1 []uint64
	value2 string
}

func (s *struct2) Encode() []byte {
	value1Encoded := primitiveEncode.EncodeUint64Slice(s.value1)
	value2Encoded := primitiveEncode.EncodeString(s.value2)
	return append(value1Encoded, value2Encoded...)
}
func (s *struct2) Decode(b []byte) {
	value1Size := primitiveEncode.DecodeInt32(b[:4]) * 8
	s.value1 = primitiveEncode.DecodeUint64Slice(b[:4+value1Size])
	s.value2 = primitiveEncode.DecodeString(b[4+value1Size:])
}
func (s *struct2) TypeId() uint32 {
	return 2
}

func main() {
	// Testing single value struct
	fmt.Println("---- test 1 ----")
	s1 := &struct1{value: []int32{11, 12}}
	fmt.Println("Original struct:", *s1)
	auto.SetType(s1.TypeId(), func() auto.Struct {
		return &struct1{}
	})
	path1 := "/Users/kirillovmr/GitHub/cs485/assignment1/str1"
	auto.Write(path1, s1)
	decodedStruct1, err := auto.Read(path1)
	fmt.Println("auto.Read() result:", decodedStruct1, err)
	var decodedStruct11 struct1 = *decodedStruct1.(*struct1)
	fmt.Println("Cast back to original structure:", decodedStruct11)

	// Testing without auto.SetType()
	fmt.Println("\n---- test 2 (without auto.SetType()) ----")
	s2 := &struct2{value1: []uint64{44444}, value2: "auto.Read() shouldn't decode me"}
	fmt.Println("Original struct:", *s2)
	path2 := "/Users/kirillovmr/GitHub/cs485/assignment1/str2"
	auto.Write(path2, s2)
	decodedStruct2, err := auto.Read(path2)
	fmt.Println("auto.Read() result:", decodedStruct2, err)

	// Testing compound value struct
	fmt.Println("\n---- test 3 ----")
	s3 := &struct2{value1: []uint64{1, 2, 3}, value2: "hey"}
	fmt.Println("Original struct:", *s3)
	auto.SetType(s3.TypeId(), func() auto.Struct {
		return &struct2{}
	})
	path3 := "/Users/kirillovmr/GitHub/cs485/assignment1/str3"
	auto.Write(path3, s3)
	decodedStruct3, err := auto.Read(path3)
	fmt.Println("auto.Read() result:", decodedStruct3, err)
	var decodedStruct33 struct2 = *decodedStruct3.(*struct2)
	fmt.Println("Cast back to original structure:", decodedStruct33)
}
