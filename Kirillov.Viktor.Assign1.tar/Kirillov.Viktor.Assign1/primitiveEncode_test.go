package primitiveEncode_test

import (
	"bytes"
	"ethos/primitiveEncode"
	"reflect"
	"testing"
)

func TestEncodeInt32(t *testing.T) {
	input := int32(32)
	actual := primitiveEncode.EncodeInt32(input)
	expected := []byte{32, 0, 0, 0}
	if bytes.Compare(actual, expected) != 0 {
		t.Errorf("EncodeInt32(%d) = %d; want %d", input, actual, expected)
	}
}

func TestDecodeInt32(t *testing.T) {
	input := []byte{44, 0, 0, 0}
	actual := primitiveEncode.DecodeInt32(input)
	expected := int32(44)
	if actual != expected {
		t.Errorf("DecodeInt32(%d) = %d; want %d", input, actual, expected)
	}
}

func TestEncodeUint64(t *testing.T) {
	input := uint64(64)
	actual := primitiveEncode.EncodeUint64(input)
	expected := []byte{64, 0, 0, 0, 0, 0, 0, 0}
	if bytes.Compare(actual, expected) != 0 {
		t.Errorf("EncodeUint64(%d) = %d; want %d", input, actual, expected)
	}
}

func TestDecodeUint64(t *testing.T) {
	input := []byte{76, 0, 0, 0, 0, 0, 0, 0}
	actual := primitiveEncode.DecodeUint64(input)
	expected := uint64(76)
	if actual != expected {
		t.Errorf("DecodeUint64(%d) = %d; want %d", input, actual, expected)
	}
}

func TestEncodeInt32Slice(t *testing.T) {
	input := []int32{32, 33}
	actual := primitiveEncode.EncodeInt32Slice(input)
	expected := []byte{2, 0, 0, 0, 32, 0, 0, 0, 33, 0, 0, 0}
	if bytes.Compare(actual, expected) != 0 {
		t.Errorf("EncodeInt32Slice(%d) = %d; want %d", input, actual, expected)
	}
}

func TestDecodeInt32Slice(t *testing.T) {
	input := []byte{2, 0, 0, 0, 32, 0, 0, 0, 33, 0, 0, 0}
	actual := primitiveEncode.DecodeInt32Slice(input)
	expected := []int32{32, 33}
	if !reflect.DeepEqual(actual, expected) {
		t.Errorf("DecodeInt32Slice(%d) = %d; want %d", input, actual, expected)
	}
}

func TestEncodeUint64Slice(t *testing.T) {
	input := []uint64{32, 33}
	actual := primitiveEncode.EncodeUint64Slice(input)
	expected := []byte{2, 0, 0, 0, 32, 0, 0, 0, 0, 0, 0, 0, 33, 0, 0, 0, 0, 0, 0, 0}
	if bytes.Compare(actual, expected) != 0 {
		t.Errorf("EncodeUint64Slice(%d) = %d; want %d", input, actual, expected)
	}
}

func TestDecodeUint64Slice(t *testing.T) {
	input := []byte{2, 0, 0, 0, 32, 0, 0, 0, 0, 0, 0, 0, 33, 0, 0, 0, 0, 0, 0, 0}
	actual := primitiveEncode.DecodeUint64Slice(input)
	expected := []uint64{32, 33}
	if !reflect.DeepEqual(actual, expected) {
		t.Errorf("DecodeUint64Slice(%d) = %d; want %d", input, actual, expected)
	}
}

func TestEncodeString(t *testing.T) {
	input := "ABC"
	actual := primitiveEncode.EncodeString(input)
	expected := []byte{3, 0, 0, 0, 65, 66, 67}
	if bytes.Compare(actual, expected) != 0 {
		t.Errorf("EncodeString(%s) = %d; want %d", input, actual, expected)
	}
}

func TestDecodeString(t *testing.T) {
	input := []byte{3, 0, 0, 0, 65, 66, 67}
	actual := primitiveEncode.DecodeString(input)
	expected := "ABC"
	if !reflect.DeepEqual(actual, expected) {
		t.Errorf("DecodeString(%d) = %s; want %s", input, actual, expected)
	}
}
